import{f as s}from"./index-BJCepwD8.js";const e=s("Minus",[["path",{d:"M5 12h14",key:"1ays0h"}]]);export{e as M};
