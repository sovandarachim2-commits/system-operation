import{e}from"./index-ClkBFGLE.js";const h=e("ChevronRight",[["path",{d:"m9 18 6-6-6-6",key:"mthhwq"}]]);export{h as C};
