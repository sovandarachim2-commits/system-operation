import{f as c}from"./index-BOHyaEv4.js";const e=c("Clock3",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["polyline",{points:"12 6 12 12 16.5 12",key:"1aq6pp"}]]);export{e as C};
