import{e}from"./index-DnFjfSft.js";const h=e("ChevronRight",[["path",{d:"m9 18 6-6-6-6",key:"mthhwq"}]]);export{h as C};
